# Student Performance Management System
# Frontend: Shiny | Backend: R | Database: SQLite

library(shiny)
library(DBI)
library(RSQLite)
library(ggplot2)

# ---------------- BACKEND: DATABASE ----------------
DB_FILE <- "students.db"

get_connection <- function() {
  dbConnect(SQLite(), DB_FILE)
}

initialize_database <- function() {
  con <- get_connection()
  on.exit(dbDisconnect(con))
  dbExecute(con, "
    CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      roll_no TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      department TEXT NOT NULL,
      year INTEGER NOT NULL,
      python REAL NOT NULL,
      statistics REAL NOT NULL,
      r_programming REAL NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
  ")
}

get_students <- function() {
  con <- get_connection()
  on.exit(dbDisconnect(con))
  dbGetQuery(con, "
    SELECT id, roll_no, name, department, year,
           python, statistics, r_programming, created_at
    FROM students ORDER BY id DESC
  ")
}

add_student <- function(roll_no, name, department, year,
                        python, statistics, r_programming) {
  # Backend validation
  if (any(!nzchar(trimws(c(roll_no, name, department))))) {
    stop("Please fill in all text fields.")
  }
  marks <- c(python, statistics, r_programming)
  if (any(is.na(marks)) || any(marks < 0 | marks > 100)) {
    stop("Marks must be between 0 and 100.")
  }
  if (year < 1 || year > 6) stop("Enter a valid year.")

  con <- get_connection()
  on.exit(dbDisconnect(con))
  dbExecute(con, "
    INSERT INTO students
      (roll_no, name, department, year, python, statistics, r_programming)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  ", params = list(
    trimws(roll_no), trimws(name), trimws(department), as.integer(year),
    python, statistics, r_programming
  ))
}

delete_student <- function(student_id) {
  con <- get_connection()
  on.exit(dbDisconnect(con))
  dbExecute(con, "DELETE FROM students WHERE id = ?", params = list(student_id))
}

prepare_results <- function(df) {
  if (nrow(df) == 0) return(df)
  df$total <- df$python + df$statistics + df$r_programming
  df$average <- round(df$total / 3, 2)
  df$result <- ifelse(
    df$python >= 40 & df$statistics >= 40 & df$r_programming >= 40,
    "Pass", "Fail"
  )
  df$grade <- ifelse(df$average >= 90, "A+",
              ifelse(df$average >= 80, "A",
              ifelse(df$average >= 70, "B",
              ifelse(df$average >= 60, "C",
              ifelse(df$average >= 50, "D",
              ifelse(df$average >= 40, "E", "F"))))))
  df
}

initialize_database()

# ---------------- FRONTEND: SHINY UI ----------------
ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      body { background:#f3f6fb; color:#243247; font-family:Arial,sans-serif; }
      .navbar { background:#183b66; padding:15px; color:white; border-radius:8px; }
      .navbar h2 { color:white; margin:4px; }
      .cardbox { background:white; border-radius:12px; padding:18px;
                 margin:8px 0 16px 0; box-shadow:0 2px 8px #dce3ed; }
      .cardbox h4 { color:#53657c; margin-top:0; }
      .metric { font-size:27px; font-weight:bold; color:#1c5d99; }
      .btn-primary { background:#1c65a8; border-color:#1c65a8; }
      .sidebar { background:white; padding:16px; border-radius:12px; }
      h3 { color:#183b66; }
    "))
  ),

  div(class="navbar",
      h2("Student Performance Management System"),
      p("Manage student records • Analyze marks • Generate reports")),

  br(),
  sidebarLayout(
    sidebarPanel(
      class="sidebar",
      h3("Navigation"),
      radioButtons("page", "Choose a section",
        choices=c("Dashboard"="dashboard",
                  "Add Student"="add",
                  "Student Records"="records",
                  "Performance Analytics"="analytics"),
        selected="dashboard"),
      hr(),
      p("Database: SQLite"),
      p("Backend: R functions"),
      p("Frontend: Shiny")
    ),

    mainPanel(
      uiOutput("page_content")
    )
  )
)

# ---------------- FRONTEND/BACKEND CONNECTION ----------------
server <- function(input, output, session) {
  refresh <- reactiveVal(0)
  notice <- reactiveVal(NULL)

  all_results <- reactive({
    refresh()
    prepare_results(get_students())
  })

  output$page_content <- renderUI({
    switch(input$page,
      dashboard = tagList(
        h3("Dashboard Overview"),
        fluidRow(
          column(4, div(class="cardbox", h4("Total Students"),
                        div(class="metric", textOutput("total_students")))),
          column(4, div(class="cardbox", h4("Passed Students"),
                        div(class="metric", textOutput("passed_students")))),
          column(4, div(class="cardbox", h4("Class Average"),
                        div(class="metric", textOutput("class_average"))))
        ),
        div(class="cardbox", h3("Recent Student Results"),
            tableOutput("recent_table"))
      ),

      add = tagList(
        h3("Add New Student"),
        div(class="cardbox",
          p("Enter the student's details and marks out of 100."),
          textInput("roll_no", "Roll Number"),
          textInput("name", "Student Name"),
          textInput("department", "Department", value="BCom IT"),
          numericInput("year", "Year of Study", value=2, min=1, max=6),
          fluidRow(
            column(4, numericInput("python", "Python Marks", value=0, min=0, max=100)),
            column(4, numericInput("statistics", "Statistics Marks", value=0, min=0, max=100)),
            column(4, numericInput("r_programming", "R Programming Marks", value=0, min=0, max=100))
          ),
          actionButton("save_student", "Save Student", class="btn-primary"),
          br(), br(),
          textOutput("save_message")
        )
      ),

      records = tagList(
        h3("Student Records"),
        div(class="cardbox",
          textInput("record_search", "Search by roll number, name or department"),
          tableOutput("records_table"),
          br(),
          downloadButton("download_records", "Download CSV"),
          hr(),
          h4("Delete a record"),
          numericInput("delete_id", "Database ID to delete", value=1, min=1, step=1),
          actionButton("delete_student", "Delete Record", class="btn-danger"),
          br(), br(),
          textOutput("delete_message")
        )
      ),

      analytics = tagList(
        h3("Performance Analytics"),
        div(class="cardbox",
          h4("Average Marks by Student"),
          plotOutput("average_plot", height="350px")
        ),
        div(class="cardbox",
          h4("Pass and Fail Distribution"),
          plotOutput("result_plot", height="300px")
        ),
        div(class="cardbox",
          h4("Subject-wise Average"),
          plotOutput("subject_plot", height="300px")
        )
      )
    )
  })

  output$total_students <- renderText(nrow(all_results()))
  output$passed_students <- renderText({
    df <- all_results()
    if (!nrow(df)) return("0")
    sum(df$result == "Pass")
  })
  output$class_average <- renderText({
    df <- all_results()
    if (!nrow(df)) return("N/A")
    paste0(round(mean(df$average), 1), " / 100")
  })

  output$recent_table <- renderTable({
    df <- all_results()
    if (!nrow(df)) return(data.frame(Message="No students yet. Use Add Student to begin."))
    head(df[, c("roll_no", "name", "department", "average", "grade", "result")], 8)
  }, striped=TRUE, bordered=TRUE, spacing="s")

  observeEvent(input$save_student, {
    notice(NULL)
    tryCatch({
      add_student(input$roll_no, input$name, input$department, input$year,
                  input$python, input$statistics, input$r_programming)
      refresh(refresh() + 1)
      notice("Student saved successfully.")
      updateTextInput(session, "roll_no", value="")
      updateTextInput(session, "name", value="")
      updateNumericInput(session, "python", value=0)
      updateNumericInput(session, "statistics", value=0)
      updateNumericInput(session, "r_programming", value=0)
    }, error=function(e) {
      notice(paste("Could not save:", conditionMessage(e)))
    })
  })

  output$save_message <- renderText({
    if (is.null(notice())) "" else notice()
  })

  output$records_table <- renderTable({
    df <- all_results()
    if (nrow(df) && nzchar(trimws(input$record_search))) {
      q <- trimws(input$record_search)
      keep <- grepl(q, df$roll_no, ignore.case=TRUE) |
              grepl(q, df$name, ignore.case=TRUE) |
              grepl(q, df$department, ignore.case=TRUE)
      df <- df[keep, ]
    }
    if (!nrow(df)) return(data.frame(Message="No matching records"))
    df[, c("id", "roll_no", "name", "department", "year",
           "python", "statistics", "r_programming",
           "total", "average", "grade", "result")]
  }, striped=TRUE, bordered=TRUE, spacing="s")

  observeEvent(input$delete_student, {
    tryCatch({
      delete_student(as.integer(input$delete_id))
      refresh(refresh() + 1)
      notice("Delete operation completed.")
    }, error=function(e) {
      notice(paste("Could not delete:", conditionMessage(e)))
    })
  })
  output$delete_message <- renderText({
    if (is.null(notice())) "" else notice()
  })

  output$download_records <- downloadHandler(
    filename=function() paste0("student_results_", Sys.Date(), ".csv"),
    content=function(file) {
      write.csv(all_results(), file, row.names=FALSE)
    }
  )

  output$average_plot <- renderPlot({
    df <- all_results()
    validate(need(nrow(df) > 0, "Add students to display this chart."))
    ggplot(df, aes(x=reorder(name, average), y=average)) +
      geom_col(fill="#3478b8") + coord_flip() +
      ylim(0, 100) +
      labs(x="Student", y="Average Marks", title="Student Average Marks") +
      theme_minimal(base_size=12)
  })

  output$result_plot <- renderPlot({
    df <- all_results()
    validate(need(nrow(df) > 0, "Add students to display this chart."))
    counts <- as.data.frame(table(df$result))
    names(counts) <- c("Result", "Students")
    ggplot(counts, aes(x="", y=Students, fill=Result)) +
      geom_col(width=1) + coord_polar("y") +
      labs(x=NULL, y=NULL, title="Pass and Fail Distribution") +
      theme_void()
  })

  output$subject_plot <- renderPlot({
    df <- all_results()
    validate(need(nrow(df) > 0, "Add students to display this chart."))
    subject_means <- data.frame(
      Subject=c("Python", "Statistics", "R Programming"),
      Average=c(mean(df$python), mean(df$statistics), mean(df$r_programming))
    )
    ggplot(subject_means, aes(x=Subject, y=Average, fill=Subject)) +
      geom_col(show.legend=FALSE) + ylim(0, 100) +
      labs(x="Subject", y="Average Marks", title="Subject-wise Average") +
      theme_minimal(base_size=12)
  })
}

shinyApp(ui=ui, server=server)
