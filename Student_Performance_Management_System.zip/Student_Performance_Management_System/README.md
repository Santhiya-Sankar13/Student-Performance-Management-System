# Student Performance Management System

A full-stack-style student performance application built in R.

## Features
- Shiny frontend with Dashboard, Add Student, Student Records, and Analytics sections
- R backend functions for validation, CRUD operations, totals, averages, grades, and pass/fail calculation
- SQLite database persists student records in `students.db`
- Search student records
- Delete records by database ID
- Export results to CSV
- Charts for student averages, pass/fail distribution, and subject-wise averages

## Requirements
- R and RStudio
- Packages: `shiny`, `DBI`, `RSQLite`, `ggplot2`

## Run
1. Open this folder in RStudio.
2. In the Console, install packages once:
   ```r
   install.packages(c("shiny", "DBI", "RSQLite", "ggplot2"))
   ```
3. Make sure the working directory is this project folder.
4. Run:
   ```r
   shiny::runApp()
   ```
5. Add student records in the app. The SQLite database file `students.db` is created automatically.

## Marks and results
Marks are out of 100. A student passes only if all three subject marks are at least 40. Grades are calculated from the overall average.

## Project architecture
- Frontend: Shiny UI and HTML/CSS styling
- Backend: R functions, validation, and calculations
- Database: SQLite (`students.db`)
- Charts: ggplot2

This is an educational portfolio project; use fictional sample student data for public demos.
